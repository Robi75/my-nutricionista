MI NUTRICIONISTA v3 — DESPENSA + PLAN + COMPRA

Incluye:
- Objetivos diarios personalizados: 2.300 kcal; 180–190 P; 200–220 C; 65–75 G.
- Ingestas fijas de la mañana.
- Despensa con cantidades.
- Entrada rápida de alimentos por texto.
- Menú diario con comida y cena, gramos, macros y receta.
- Botón "Aprovechar lo que tengo".
- Descuento de cantidades al marcar un menú como consumido.
- Planificación de 1 a 4 semanas.
- Variedad normal o alta.
- Lista de compra calculada como necesidades del plan menos stock.
- Copia de la lista de compra.
- Registro de peso.
- Almacenamiento local en el dispositivo.
- Sin cuenta y sin servidor de datos.

INSTALACIÓN EN IPHONE:
1. Publicar estos archivos en HTTPS (por ejemplo GitHub Pages).
2. Abrir index.html desde Safari.
3. Compartir -> Añadir a pantalla de inicio.

NOTA:
Esta es una PWA funcional de prototipo. Los cálculos son aproximados y deben ajustarse a las etiquetas reales de los productos. No sustituye consejo médico o dietético profesional.
